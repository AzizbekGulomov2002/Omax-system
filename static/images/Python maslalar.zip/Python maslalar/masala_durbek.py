# Masala_1

# Shunday funksiya tuzingki, qiymatni matn ko'rinishida kiritishni so'rasin, kiritilgan matnni hammasini bosh harfda qaytarsin

