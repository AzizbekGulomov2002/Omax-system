

# Masala_1

# Istalgan butun son kiritish so'ralsin, son kiritilganida, shu songacha bo'lgan yig'indini qaytarsin


# Masalan: son kiriting: 12
# Javob = 78 (ya'ni 0+1+2+3+4+5+6+7+8+9+10+11+12)


# son = int(input("Istalgan sonni kiriting = "))
# yigindi = sum(range(son+1))
# print(son, " gacha sonlarning yig'indisi =  ", yigindi)


##############################################################################################


#Masala_2

# Uchburchak tomonlari orqali - shu uchburchak to'g'ri yoki xato ekanini tekshiruvcha shart algoritm tuzilsin
# Uchburchak tuzish qoidasi - istalgan 2ta tomonini qo'shganda uchinchi tomonidan katta bo'lishi shart
# Masalan:

# Uchburchak birinchi tomoni = 10
# Uchburchak ikkinchi tomoni = 5
# Uchburchak uchinchi tomoni= 3
# Javob: Bundan uchburchak yasab bo'lmaydi


# tomon1 = int(input("Birinchi tomon = "))
# tomon2 = int(input("Ikkinchi tomon = "))
# tomon3 = int(input("Uchinchi tomon = "))
# if tomon1+tomon2>=tomon3:
#     print("Uchburchak yasash mumkin")
# elif tomon1+tomon3>=tomon2:
#     print("Uchburchak yasash mumkin")
# elif tomon2+tomon3>=tomon1:
#     print("Uchburchak yasash mumkin")
# else:
#     print("Uchburchak yasab bo'lmaydi")


##############################################################################################


# Masala_3

# Matn kiriting degan input qiymat so'ralganida va matn kiritilganida, shu matnda a harfi qatnashgani yoki yo'qligi, va sonini qaytaruvchi algoritm tuzilsin

# Masalan:

# Matn kiriting = Assalomu alaykum
# Javob: Ushbu matndagi a harflar soni = 3 ta
# Matn kiriting = Bro
# Javob : Ushbu matnda a harfi ishtirok etmagan


# matn = input("Matn kiriting = ")
# print("Matndagi a harflar soni = ",matn.count('a'), "ta ekan")


##############################################################################################


