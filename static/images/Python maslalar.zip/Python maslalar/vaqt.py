import calendar


# yil = int(input("Yilni kiriting = "))
# oy = int(input("Oyni kiriting = "))
# print(calendar.month(yil,oy))



for i in range(10):
 print(str(i) * i)